import logo from './logo.svg';
import './App.css';
import './'
import Homepage from './components/Homepage';

function App() {
  return (
    <div className="App">
      <h2>Users List</h2>
      <Homepage />
    </div>
  );
}

export default App;
